import java.util.Scanner;
/**
 * Greek's method to approximate the square root of a given number.
 */
public class SquareRootComputer {
	public static void main(String[] args) {
		// this is your tester
		// read a value from the user and print the results 
		// along with expected value
		Scanner input = new Scanner(System.in);
		int start = 0;
		//start will be greater than zero of a negative number is entered
		while(start == 0)
		{
		   System.out.print("Enter a number(A negative number will stop simulation): ");
		   double num = input.nextDouble(); //store number
		   //if num is positive run calculations
		   if(num >= 0)
		   {
		      System.out.println("The square root of " + num + " is " + squareRoot(num)); //printing the sqrt of the num
		      System.out.print("Expected value: " + (double)Math.round(Math.sqrt(num)*100000) / 100000); //rounding expected to 5 decimals
		      System.out.println("");
		      System.out.println("");
		   }
		   //if num is neg. end program
		   else{System.out.println("Simulation stopped because a negative number was entered. Good Bye!"); start++;}
        }
	}

	public static double squareRoot(double x) {
		// from this method come up with a guess
		// and then make the call to the recursive method
		// squareRootGuesser()
		//guess is equal to input num divided by 2
		double guess = (x/2);
		//call squareRooteGuess method
		//@param x is input num
		//@param guess is the guess used to run recursion case
		return squareRootGuess(x,guess);
	}

	private static double squareRootGuess(double x, double g) {
		// recursive method to compute the square root of x
		// you will need to have a base case and a recursive case
		// in this method
		if(Math.abs(((x) - (g*g))) < .0001) //base case
		{
		    return (double)Math.round(g*100000) / 100000; //round answer to 5 decimals
		}
		else //recursion case
		{
		   // Greek Formula used to calculate sqrt
		   g = ((g + (x/g)) / 2);
		   return squareRootGuess(x,g);
		}
	}
}
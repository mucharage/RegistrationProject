
public class CircuitTester01 {

	public static void main(String[] args) {
		
		Serial c1 = new Serial();
		c1.add(new Resistor(100));
		c1.add(new Resistor(200));
		c1.add(new Resistor(150));
		
		System.out.println("c1 total R = " + c1.getResistance());
		
		Parallel c2 = new Parallel();
		c2.add(new Resistor(100));
		c2.add(new Resistor(100));
		c2.add(new Resistor(100));
		
		System.out.println("c2 total R = " + c2.getResistance());
		
		Serial c3 = new Serial();
		c3.add(c1);
		c3.add(c2);

		System.out.println("c3 total R = " + c3.getResistance());
		
		Parallel c4 = new Parallel();
		c4.add(c1);
		c4.add(c2);
		
		System.out.println("c4 total R = " + c4.getResistance());
	}

}

/**
 * Write a description of class Serial here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
import java.util.ArrayList;
public class Serial extends Circuit
{
    //ArrayList<Circuit> as instance variable
    private ArrayList<Circuit> list = new ArrayList<Circuit>();
    
    //recieves values for ArrayList
    public void add(Circuit dd)
    {
        list.add(dd);//adding value to ArrayList at element i
    }
    
    
    
    public double getResistance()
    {
        double total = 0;
        for(int i = 0; i <list.size(); i++)
        {   //calculating the value's resistance at element i
            total = (list.get(i).getResistance() + total);
        }
        return total;
    }
}

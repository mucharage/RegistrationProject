
/**
 * Write a description of class Resistor here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Resistor extends Circuit
{
    // instance variables
    private double resistance;
    /**
     * Constructor for objects of class Resistor
     */
    public Resistor(double res)
    {
        // initialise instance variables
        resistance = res;
    }
    //call the getResistance in the super class instead of calling itself
    public double getResistance()
    {
        return resistance;
    }
}

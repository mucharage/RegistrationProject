
/**
 * Class that serves as a parents class for the other folders.
 * 
 * @author (Steven Hullander) 
 * @version (2/5/2015)
 */
public class Circuit
{
    public double getResistance()
    {
        //return 0
        return 0;
    }
}

/**
 * A class to run tests on the Circuit class and subclasses
 * @author Horstman
 * @version 02/06/2014
 *  
 */

public class CircuitDemo
{	/**
	method that implements tests for Circuit class and sublclasses
	@param args - Not Used.
 	*/
	
   public static void main(String[] args)
   {
       //test number 1
      Parallel circuit1 = new Parallel();
      circuit1.add(new Resistor(100));
      Serial circuit2 = new Serial();
      circuit2.add(new Resistor(100));
      circuit2.add(new Resistor(200));
      circuit1.add(circuit2);
      System.out.println("Combined resistance: " + circuit1.getResistance());
      System.out.println("Expected: 75.0");
      System.out.println();
      System.out.println();
      
      
       //test number 2
      Parallel circuit3 = new Parallel();
      circuit3.add(new Resistor(200));
      Serial circuit4 = new Serial();
      circuit4.add(new Resistor(400));
      circuit4.add(new Resistor(300));
      circuit3.add(circuit4);
      System.out.println("Combined resistance: " + circuit3.getResistance());
      System.out.println("Expected: 155.5555555");
      System.out.println();
      System.out.println();
      
      
      
       //test number 3
      Parallel circuit5 = new Parallel();
      circuit5.add(new Resistor(-50));
      Serial circuit6 = new Serial();
      circuit6.add(new Resistor(-50));
      circuit6.add(new Resistor(-2));
      circuit5.add(circuit6);
      System.out.println("Combined resistance: " + circuit5.getResistance());
      System.out.println("Expected: -25.49019608");
      System.out.println();
      System.out.println();
      
      
      
       //test number 4
      Parallel circuit7 = new Parallel();
      circuit7.add(new Resistor(20));
      Serial circuit8 = new Serial();
      circuit8.add(new Resistor(400));
      circuit8.add(new Resistor(1));
      circuit7.add(circuit8);
      System.out.println("Combined resistance: " + circuit7.getResistance());
      System.out.println("Expected: 19.04988123");
   }
}

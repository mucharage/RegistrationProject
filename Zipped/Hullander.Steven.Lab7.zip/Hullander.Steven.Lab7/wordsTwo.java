
/**
 * Compare 2 words
 * 
 * @author (Steven Hullander) 
 * @version (11/3/2014)
 */
import java.util.Scanner;
public class wordsTwo
{
     public static void main (String[] args)
    {   Scanner in = new Scanner (System.in);
        System.out.print("Enter the first word: ");
        String word1 = in.next();
        System.out.print("Enter the second word: ");
        String word2 = in.next();
        if (word1.equalsIgnoreCase(word2))
         {
           System.out.print("The wordss are equal!");
         }
        else 
         {
           System.out.print("The words are not equal!");
         }
    }
}

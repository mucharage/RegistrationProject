
/**
 * Tip satisfaction calculator tester.
 * 
 * @author (Steven Hullander) 
 * @version (10/27/2014)
 */
import java.util.Scanner;
public class tipTester
{
   public static void main(String[] args)
   {
       Scanner scan = new Scanner(System.in);
       System.out.println("Please enter the cost of your meal: ");
       double foodCost = scan.nextDouble();
       System.out.println("Please enter your satisfaction rating(1 for totally satisfied, 2 for satisfied, and 3 for dissatisfied): ");
       int satisfaction = scan.nextInt();
       Tip satisfy = new Tip(satisfaction);
       double tipAmount = satisfy.calcTip(foodCost);
       double totalMeal = (foodCost + tipAmount);
       if(satisfaction == 1)
       {
         System.out.println("Satisfaction level: Very Satisfied");
         System.out.println("Food cost: " + foodCost);
         System.out.println("Tip amount based on satisfaction rate: " + tipAmount);
         System.out.println("Meal total: " + totalMeal);
       }
       if(satisfaction == 2)
       {
         System.out.println("Satisfaction level: Satisfied");
         System.out.println("Food cost: " + foodCost);
         System.out.println("Tip amount based on satisfaction rate: " + tipAmount);
         System.out.println("Meal total: " + totalMeal);
       }
       if(satisfaction == 3)
       {
         System.out.println("Satisfaction level: Dissatisfied");
         System.out.println("Food cost: " + foodCost);
         System.out.println("Tip amount based on satisfaction rate: " + tipAmount);
         System.out.println("Meal total: " + totalMeal);
       }
       else
       {
         System.out.println("Sorry. " + satisfaction + " is an invalid response.");
       }
   }
}

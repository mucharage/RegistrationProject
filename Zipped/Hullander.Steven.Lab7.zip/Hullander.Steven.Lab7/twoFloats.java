/**
 * compare two floating point numbers
 * 
 * @author (Steven Hullander) 
 * @version (11/3/2014)
 */
import java.util.Scanner;
public class twoFloats
  {
    public static void main (String[] args)
     {
       Scanner scan = new Scanner(System.in);
       System.out.print("Enter a number: ");
       double num1 = scan.nextDouble();
       System.out.print("Enter a number: ");
       double num2 = scan.nextDouble();
       double closeEnough = 0.01;
       if(Math.abs(num1-num2) < closeEnough)
         {
           System.out.print("The two numbers are equal!");
         }
       else
         {
             System.out.print("The numbers are not equal!");
         }
     }
}
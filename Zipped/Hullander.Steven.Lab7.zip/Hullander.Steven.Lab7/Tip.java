
/**
 * Tip satisfaction calculator.
 * 
 * @author (Steven Hullander) 
 * @version (10/27/2014)
 */
public class Tip
{
    private int satisfactionRating;
    double tipAmount = 0;
    public Tip(int x)
    {
        satisfactionRating = x;
    }

    public double calcTip(double bill)
    {
        if(satisfactionRating == 1)
        {
            tipAmount = (bill * .20);
        }
        if(satisfactionRating == 2)
        {
            tipAmount = (bill * .15);
        }
        if(satisfactionRating == 3)
        {
           tipAmount = (bill * .10);
        }
        return tipAmount;
    }
}


/**
 * Compare 2 sentences.
 * 
 * @author (Steven Hullander) 
 * @version (11/3/2014)
 */
import java.util.Scanner;
public class sentencesTwo
{
     public static void main (String[] args)
    {   Scanner in = new Scanner (System.in);
        System.out.print("Enter the first sentence: ");
        String sent1 = in.nextLine();
        System.out.print("Enter the second sentence: ");
        String sent2 = in.nextLine();
        if (sent1.equalsIgnoreCase(sent2))
         {
           System.out.print("The sentences are equal");
         }
        else 
         {
           System.out.print("The sentences are not equal");
         }
    }
}

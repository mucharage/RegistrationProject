/**
 * A class to test the method of the BankAccount class.
 * 
 * @author (Steven Hullander) 
 * @version (11/3/2014)
 */
import java.util.Scanner;
public class BankAccountTesterUpdated
{
    public static void main(String[] args)
    {  
       Scanner in = new Scanner(System.in);
       BankAccountUpdated harrysChecking = new BankAccountUpdated ();
       System.out.print("Enter an amount to deposit: ");
       double depositAmount = in.nextDouble();
       if(depositAmount < 0)
         {
             System.out.println("Invalid Input.");
         }
       else
         {
             harrysChecking.deposit(depositAmount);
         }
       System.out.print("Enter an amount to withdraw: ");
       double withdrawAmount = in.nextDouble();
       if(withdrawAmount < 0)
         {
             System.out.println("Invalid Input.");
         }
       else
         {
             harrysChecking.withdraw(withdrawAmount);
         }
       System.out.println("Account total: "+ harrysChecking.getBalance());
    }
}


/**
 * Write a description of class PrintItTester here.
 * 
 * @author (Steven Hullander) 
 * @version (11/16/2014)
 */
import java.util.Scanner;
public class PrintItTester
{
   public static void main(String[] args)
   {
     int[] numsList = new int[10];
     Scanner in = new Scanner(System.in);
     for(int i=0;i<=9;i++)
       {
         System.out.print("Please enter a number: ");
         int input = in.nextInt();
         numsList[i] = input;
       }
     PrintIt ray = new PrintIt(numsList);
     System.out.print("The values in order are: ");
     ray.printOrder();
     System.out.println(" ");
     System.out.print("The values in reverse order are: ");
     ray.printReverse();
   }
}

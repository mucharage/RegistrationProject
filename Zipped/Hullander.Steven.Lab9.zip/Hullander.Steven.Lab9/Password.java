
/**
 * Write a description of class Password here.
 * 
 * @author (Steven Hullander) 
 * @version (11/16/2014)
 */
import java.util.Scanner;
public class Password
{
  public static void main(String[] args)
   {
      Scanner in = new Scanner(System.in);
      String[] passwords = new String [10];
      for(int i=0;i<10;i++)
        {
           System.out.print("Please enter in a password to save: ");
           String input = in.nextLine();
           passwords[i] = input;
        }
      System.out.print("Please enter in a password: ");
      String input = in.nextLine();
      int count=0;
      for(int i=0;i<10;i++)
        {
          if(input == passwords[i])
           {
              count++;
           }
          else
           {
              count=count;
           }
        }
          if(count >0)
           {
              System.out.print("Valid Password! ");
           }
          else
           {
              System.out.print("Invalid Password! ");
           }
     
   }
}

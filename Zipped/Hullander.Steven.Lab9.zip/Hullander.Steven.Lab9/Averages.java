
/**
 * Class to find the average of the odd and even input stored in the array.
 * 
 * @author (Steven Hullander) 
 * @version (11/16/2014)
 */
public class Averages
{
    private int[] numsList;
    private int oddAverage;
    private int evenAverage;
    public int evenSum=0;
    public int evenCount=0;
    public int oddSum=0;
    public int oddCount=0;
    public Averages(int[] a)
    {
        numsList = a;
        oddAverage = 0;
        evenAverage = 0;
    }
    public void calcAverage()
    {
        for(int i=0; i<=9; i++)
        {
          if(numsList[i] % 2 == 0)
            {
               evenSum = evenSum + numsList[i];
               evenCount = evenCount + 1;
            }
          else
            {
               oddSum = oddSum + numsList[i];
               oddCount = oddCount + 1;
            }
        }
        oddAverage = (oddSum/oddCount);
        evenAverage = (evenSum/evenCount);
    }
    public int getEvenAverage()
    {
        return evenAverage;
    }
    public int getOddAverage()
    {
        return oddAverage;
    }
}

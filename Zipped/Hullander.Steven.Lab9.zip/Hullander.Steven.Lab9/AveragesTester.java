
/**
 * Tester to find the average of the odd and even input stored in the array.
 * 
 * @author (Steven Hullander) 
 * @version (11/16/2014)
 */
import java.util.Scanner;
public class AveragesTester
{
    public static void main(String[] args)
    {
     Scanner in = new Scanner(System.in);
     int[] holdNums = new int[10];
     for(int i=0; i<=9; i++)
     {
       System.out.print("Please enter a number: ");
       int input = in.nextInt();
       holdNums[i] = input;
     }
     Averages ray = new Averages(holdNums);
     ray.calcAverage();
     System.out.print("The average of the even values entered is: " + ray.getEvenAverage());
     System.out.println(" ");
     System.out.print("The average of the odd values entered is: " + ray.getOddAverage());
    }
}
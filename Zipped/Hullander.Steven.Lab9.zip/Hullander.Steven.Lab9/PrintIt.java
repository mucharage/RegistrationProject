
/**
 * Write a description of class PrintIt here.
 * 
 * @author (Steven Hullander) 
 * @version (11/16/2014)
 */
public class PrintIt
{
    // instance variables 
    private int[] storeNumbers;
    public PrintIt(int[] n)
    {
        // initialise instance variables
        storeNumbers = n;
    }
    public void printOrder()
    {
       for(int i=0;i<=9;i++)
        {     
          System.out.print(storeNumbers[i] + " ");
        }
    }
    public void printReverse()
    {
       for(int i=9;i>=0;i--)
        {
          System.out.print(storeNumbers[i] + " ");
        }
    }
}

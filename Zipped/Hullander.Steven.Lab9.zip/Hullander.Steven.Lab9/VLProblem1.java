
/**
 * The Visual Logic problems in Java.
 * 
 * @author (Steven Hullander) 
 * @version (11/16/2014)
 */
import java.util.Scanner;
public class VLProblem1
{
    public static void main(String[] args)
    {
      Scanner in = new Scanner(System.in);   
      int[] storeNumbers = new int[10];
      for(int i=0;i<=9;i++)
       {
         System.out.print("Please enter a number: ");
         int input = in.nextInt();
         storeNumbers[i] = input;
       }
      System.out.print("The array values in order of entry are: ");
      for(int i=0;i<=9;i++)
       {
         System.out.print(storeNumbers[i] + " ");
       }
      System.out.println(" ");
      System.out.print("The array values in reverse order of entry are: ");
      for(int i=9;i>=0;i--)
       {
         System.out.print(storeNumbers[i] + " ");
       }
      System.out.println(" ");
      System.out.print("Every other value of the array starting from the first element is: ");
      for(int i=0;i<=8;i = i+2)
       {
         System.out.print(storeNumbers[i] + " ");
       }
    }
}

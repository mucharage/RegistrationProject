
/**
 * Write a description of class CD here.
 * 
 * @author (steven hullander) 
 * @version (12/3/2014)
 */
public class CD
{
    private String cdName;
    private String artist;
    private String[] songNames;
    public CD(String c, String a, String[] s)
    {
        // initialise instance variables
        cdName = c;
        artist = a;
        songNames = s;
    }
    public String getCD()
    {
        return cdName;
    }
    public String getArtist()
    {
        return artist;
    }
    public String[] getSongs()
    {
       return songNames;
    }
}

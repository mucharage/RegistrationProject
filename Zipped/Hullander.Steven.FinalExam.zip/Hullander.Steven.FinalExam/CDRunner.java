
/**
 * Write a description of class CDRunner here.
 * 
 * @author (steven hullander) 
 * @version (12/3/2014)
 */
import java.util.Scanner;
public class CDRunner
{
    public static void main(String[] args)
    {
      String[] CDSongs = new String[10];
      Scanner in = new Scanner(System.in);
      System.out.print("What is the name of the CD?: ");
      String cdName = in.nextLine();
      System.out.print("What is the name of the artist?: ");
      String artist = in.nextLine();
      for(int i=0; i<=9; i++)
        {
            System.out.println("Please enter the title of the song: ");
            String input = in.nextLine();
            CDSongs[i] = input;
        }
      CD ray = new CD(cdName, artist, CDSongs);
      System.out.println("The CD name is: " + ray.getCD());
      System.out.println("The CD artist is: " + ray.getArtist());
      System.out.println("The songs are: ");
      for(int i=0; i<=9; i++)
        {
           System.out.println(ray.getSongs());
        }
    }
}

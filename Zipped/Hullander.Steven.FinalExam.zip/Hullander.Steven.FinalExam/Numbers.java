
/**
 * Write a description of class Numbers here.
 * 
 * @author (steven hullander) 
 * @version (12/3/2014)
 */
import java.util.Scanner;
public class Numbers
{
    public static void main(String[] args)
    {
      int[] nums = new int[100];
      for(int i=0;i<=99;i++)
      {
       nums[i] =(i*3);
      }
      for(int i=0;i<=99;i++)
      {
       System.out.println(nums[i]);
      }
    }
}


/**
 * tester for weight for different planets.
 * 
 * @author (Steven Hullander) 
 * @version (10/12/2014)
 */
import java.util.Scanner;
public class PlanetWeightTester
{
    public static void main(String[] arg)
    {
        Scanner in = new Scanner(System.in);
        System.out.println("Please input your weight: ");
        double userWeight = in.nextDouble();
        PlanetWeightCalculator start = new PlanetWeightCalculator(userWeight);
        System.out.println("Your weight on Earth is approximately: " + Math.round(userWeight));
        System.out.println("Your weight on the moon is approximately: " + Math.round(start.getMoonWeight(userWeight)));
        System.out.println("Your weight on Mercury is approximately: " + Math.round(start.getMercuryWeight(userWeight)));
        System.out.println("Your weight on Venus is approximately: " + Math.round(start.getVenusWeight(userWeight)));
        System.out.println("Your weight on Jupiter is approximately: " + Math.round(start.getJupiterWeight(userWeight)));
        System.out.println("Your weight on Saturn is approximately: " + Math.round(start.getSaturnWeight(userWeight)));
    }
}


/**
 * printing file directories.
 * 
 * @author (Steven Hullander) 
 * @version (10/06/14)
 */
import java.util.Scanner;
public class FileDirectory
{
    public static void main(String[] args)
    {
        Scanner in = new Scanner(System.in);
        System.out.println("Enter the drive letter: ");
        String drive = in.nextLine();
        
        System.out.println("Enter the path: ");
        String path = in.nextLine();
        
        System.out.println("Enter the file name: ");
        String fileName = in.nextLine();
        
        System.out.println("Enter the extension: ");
        String extension = in.nextLine();
        
       System.out.println((drive) + ":" + (path) + "\\" + (fileName) + "." + (extension));
   }
}

/**
 * Testing the bug class
 * 
 * @author (Steven Hullander)
 * @version (10/12/2014)
 */
import java.util.Scanner;
public class BugTester
{
    public static void main (String[] args)
    {
        Scanner in = new Scanner (System.in);
        int movementDirection = 1;
        System.out.println("Enter the position of the bug: ");
        int position = in.nextInt();
        int expectedPosition = position;
        Bug start = new Bug (position);
        start.moveBug();
        if (movementDirection>0)
        {expectedPosition=expectedPosition+1;
        }
        else
        {expectedPosition=expectedPosition-1;
        }
        System.out.println("Expected Position: " + expectedPosition);
        System.out.println("Actual Position: "+ start.getPosition());
        start.moveBug();
        if (movementDirection>0)
        {expectedPosition=expectedPosition+1;
        }
        else
        {expectedPosition=expectedPosition-1;
        }
        System.out.println("Expected Position: " + expectedPosition);
        System.out.println("Actual Position: "+ start.getPosition());
        start.moveBug();
        if (movementDirection>0)
        {expectedPosition=expectedPosition+1;
        }
        else
        {expectedPosition=expectedPosition-1;
        }
        System.out.println("Expected Position: " + expectedPosition);
        System.out.println("Actual Position: "+ start.getPosition());
        start.directionChange();
        movementDirection=-1*movementDirection;
        System.out.println(" ");
        System.out.println("Direction has changed!");
        System.out.println(" ");
        System.out.println("Expected Position: " + expectedPosition);
        System.out.println("Actual Position: "+ start.getPosition());
        start.moveBug();
        if (movementDirection>0)
        {expectedPosition=expectedPosition+1;
        }
        else
        {expectedPosition=expectedPosition-1;
        }
        System.out.println("Expected Position: " + expectedPosition);
        System.out.println("Actual Position: "+ start.getPosition());
        start.moveBug();
        if (movementDirection>0)
        {expectedPosition=expectedPosition+1;
        }
        else
        {expectedPosition=expectedPosition-1;
        }
        System.out.println("Expected Position: " + expectedPosition);
        System.out.println("Actual Position: "+ start.getPosition());
        start.moveBug();
        if (movementDirection>0)
        {expectedPosition=expectedPosition+1;
        }
        else
        {expectedPosition=expectedPosition-1;
        }
        System.out.println("Expected Position: " + expectedPosition);
        System.out.println("Actual Position: "+ start.getPosition());
        start.directionChange();
        movementDirection=-1*movementDirection;
        System.out.println(" ");
        System.out.println("Direction has changed!");
        System.out.println(" ");
        System.out.println("Expected Position: " + expectedPosition);
        System.out.println("Actual Position: "+ start.getPosition());
        start.moveBug();
        if (movementDirection>0)
        {expectedPosition=expectedPosition+1;
        }
        else
        {expectedPosition=expectedPosition-1;
        }
        System.out.println("Expected Position: " + expectedPosition);
        System.out.println("Actual Position: "+ start.getPosition());
    }
}

/**
 * Find weight for different planets.
 * 
 * @author (Steven Hullander) 
 * @version (10/12/2014)
 */
public class PlanetWeightCalculator
{
    public static double weight;
    /**public PlanetWeightCalculator()
    {
        weight = 0;
    }
    */
    public PlanetWeightCalculator(double getWeight)
    { 
        weight = getWeight;
    }
    public static double getMoonWeight(double getWeight)
       {
        double moonWeight = (weight) * (0.1666);
        return moonWeight;
       }
    public static double getMercuryWeight(double getWeight)
      {
       double mercuryWeight = (weight) * (0.4);
       return mercuryWeight;
      }
    public static double getVenusWeight(double getWeight)
       {
        double venusWeight = (weight) * (0.9);
        return venusWeight;
       }
    public static double getJupiterWeight(double getWeight)
       {
        double jupiterWeight = (weight) * (2.5);
        return jupiterWeight;
       }
    public static double getSaturnWeight(double getWeight)
       {
        double saturnWeight = (weight) * (1.1);
        return saturnWeight;
       }
}


/**
 * putting commas in numbers.
 * 
 * @author (Steven Hullander) 
 * @version (10/06/14)
 */
import java.util.Scanner;
public class PutCommaIn
{
    public static void main(String[] args)
    {
        Scanner in = new Scanner(System.in);
        System.out.println("Please enter a number between 1,000 and 999,999(without the comma): ");
        String number = in.nextLine();
        int numLength = number.length();
        String upToComma = number.substring(0, numLength - 3);
        String afterComma = number.substring(numLength - 3);
        String connected = (upToComma) + "," + (afterComma);
        System.out.println(connected);
    }
}

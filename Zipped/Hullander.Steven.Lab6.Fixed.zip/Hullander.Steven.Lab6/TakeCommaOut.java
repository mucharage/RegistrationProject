
/**
 * taking commas out of numbers.
 * 
 * @author (Steven Hullander) 
 * @version (10/06/14)
 */
import java.util.Scanner;
public class TakeCommaOut
{
    public static void main(String[] args)
    {
        Scanner in = new Scanner(System.in);
        System.out.println("Please enter a number between 1,000 and 999,999(including the comma): ");
        String number = in.nextLine();
        int numLength = number.length();
        String upToComma = number.substring(0, numLength - 4);
        String afterComma = number.substring(numLength - 3);
        String connected = (upToComma) + (afterComma);
        System.out.println(connected);
    }
}


/**
 * help cashier distribute change!
 * 
 * @author (Steven Hullander) 
 * @version (10/06/14)
 */
import java.util.Scanner;
public class CorrectChange
{
    public static void main(String[] args)
    {
        Scanner in = new Scanner(System.in);
        System.out.println("Enter the amount (in cents) to return to the customer): ");
        int totalChange = in.nextInt();
        int quarters = totalChange / 25;
        int afterQuarters = totalChange % 25;
        int dimes = afterQuarters / 10;
        int afterDimes = afterQuarters % 10;
        int nickels = afterDimes / 5;
        int afterNickels = afterDimes % 5;
        int pennies = afterNickels / 1;
        System.out.println("Quarter amount is " + quarters);
        System.out.println("Dime amount is " + dimes);
        System.out.println("Nickel amount is " + nickels);
        System.out.println("Penny amount is " + pennies);
    }
}

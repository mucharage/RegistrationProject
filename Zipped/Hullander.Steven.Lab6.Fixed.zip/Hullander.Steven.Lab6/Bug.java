
/**
 * moving bug.
 * 
 * @author (Steven Hullander) 
 * @version (10/12/2014)
 */
public class Bug
{
    // Sets instance variables
    private int currentPosition;
    private int movementDirection;
    // constructor that sets location
    // of the bug based on User Input
    public Bug(int location)
      {
         currentPosition = location;
         movementDirection = 1;
      }
      // method that changes direction
      // to the opposite way
    public void directionChange()
      {
        movementDirection = -1 * movementDirection;
      }
      // if the direction is positive, the bug 
      // will continue the same way, else it will
      // and go the opposite direction
    public void moveBug()
      {
        if (movementDirection > 0)
          {
            currentPosition = currentPosition + 1;
          }     
        else
          {
            currentPosition = currentPosition - 1;
          }
      }
      // method to get the current position
    public int getPosition()
      {
        return currentPosition;
      }
}

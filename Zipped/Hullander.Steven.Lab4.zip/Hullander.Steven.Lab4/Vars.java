/**
 * Variable program.
 * 
 * @author (Steven Hullander) 
 * @version (9/22/2014)
 */
public class Vars
{
   public static void main (String[] args)
       {
        String name = "Steven Hullander";
        double price = 44.25;
        System.out.println("My name is: " + name);
        System.out.println("Price is " + price);
       }
}
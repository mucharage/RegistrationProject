/**
 * Rectangles.
 * 
 * @author (Steven Hullander) 
 * @version (9/22/2014)
 */
import java.awt.Rectangle;
public class Rex
{
   public static void main (String[] args)
       {
           Rectangle rec1 = new Rectangle(10,20,15,10);
           rec1.translate(4,-2);
           System.out.println("X is: " + rec1.getX());
           System.out.println("Y is: " + rec1.getY());
       }
}
/**
 * Practice with Strings.
 * 
 * @author (Steven Hullander) 
 * @version (9/22/2014)
 */
public class StringTest
{
   public static void main (String[] args)
       {
        String name = "Steven Hullander";
        String capName = name.toUpperCase();
        System.out.println("My name is " + name);
        System.out.println("My name in all capital letters is " + capName);
       }
}
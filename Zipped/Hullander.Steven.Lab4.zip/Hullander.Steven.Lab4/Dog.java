/**
 * Variable for dog program.
 * 
 * @author (Steven Hullander) 
 * @version (9/22/2014)
 */
public class Dog
{
   public static void main (String[] args)
       {
        String name = "Spot";
        int age = 3;
        double food = 22.36;
        System.out.println("The dog's name is " + name + ".");
        System.out.println(name + " is " + age + " years old.");
        System.out.println("His weekly food price is $ " + food);
       }
}
/**
 * Rectangle demensions.
 * 
 * @author (Steven Hullander) 
 * @version (9/22/2014)
 */
import java.awt.Rectangle;
public class RecDemensions
{
   public static void main (String[] args)
       {
           Rectangle rec1 = new Rectangle(10,20,15,10);
           System.out.println("Width is: " + rec1.getWidth());
           System.out.println("Height is: " + rec1.getHeight());
           System.out.println("Area is: " + rec1.getHeight()*rec1.getWidth());
           System.out.println("Perimeter is: " + ((rec1.getHeight()*2) + (rec1.getWidth()*2)));
       }
}
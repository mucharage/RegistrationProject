
/**
 * Calculating final cost
 * 
 * @author (Steven Hullander) 
 * @version (9/26/2014)
 */
public class taxesTester
{
   public static void main(String[] args)
    {
       Taxes george = new Taxes(.06,.04);
       george.salesTax(100.00);
       george.TotalCost();
       System.out.println("Price of purchase is $ 100.00");
       System.out.println("Total Sales Tax is " + george.getSalesTax());
       System.out.println("Expected Sales Tax is $ 10");
       System.out.println("Total Cost is " + george.getTotalCost());
       System.out.println("Expected Cost is $110");
    } 
}
/**
 *  Computer Science is Great program replacement.
 * 
 * @author (Steven Hullander) 
 * @version (9/22/2014)
 */
public class cpsIsGreat
{
   public static void main (String[] args)
       {
           String cps = "Computer Science is Great";
           String cps3 = cps.replace("e" , "3");
           System.out.println("Original: " + cps);
           System.out.println("Replacing the e's with 3's: " + cps3);
       }
}

/**
 * Setting-up for final cost.
 * 
 * @author (Steven Hullander) 
 * @version (9/26/2014)
 */
public class Taxes
{
   //There are 2 instance variables, state sales tax and county sales tax.
   private double stateTax;
   private double countyTax;
   double totalTax;
   double price;
   double cost;
   /**
    * Creating a constructor to initialize the instance variable
    */
   public Taxes (double stateSalesTax, double countySalesTax)
        {
            stateTax = stateSalesTax;
            countyTax = countySalesTax;
        }
        public void salesTax(double salesPrice)
    { 
       price = salesPrice;
       totalTax = (price * stateTax + price * countyTax);
    }
        public void TotalCost( )
    { 
       cost = (price + totalTax);
    }
    public double getSalesTax( )
    {
        return totalTax;
    }
    public double getTotalCost( )
    {
        return cost;
    }
}
    
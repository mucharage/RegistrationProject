
/**
 * Write a description of class Appointment here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Appointment
{
    // instance variables
    int day;
    int month;
    int year;
    String description;

    //returns the day
    public int getDay()
    {
        return day;
    }
    //returns the month
    public int getMonth()
    {
        return month;
    }
    //returns the year
    public int getYear()
    {
        return year;
    }
    //description for the appointment
    public String getDescription()
    {
        return description;
    }
    //prints   description,month,date,year of the appointment as a string
    public String toString()
    {
        String appoint = this.getClass().getName() + "[" + this.getDescription() + " Appointment Date: " + this.getMonth() + "/" + this.getDay() + "/" + this.getYear() + "]";
        return appoint;
    }
    //teels when the appointment is happening
    public boolean occursOn(int y, int m, int d)
    {
        boolean occurs = false;
        if(y == year && m == month && d == day)
        {
            occurs = true;
        }
        return occurs;
    }
}

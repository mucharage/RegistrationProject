
/**
 * Write a description of class Daily here.
 * 
 * @author (Steven Hullander) 
 * @version (2/19/2015)
 */
public class Daily extends Appointment
{
    //Constructor for objects of class Daily
    public Daily(int y, int m, int d, String des)
    {
        // initialise instance variables
        month = m;
        day = d;
        year = y;
        description = des;
    }
}

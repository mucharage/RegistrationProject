
/**
 * Write a description of class Monthly here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Monthly extends Appointment
{
    //Constructor for objects of class Monthly
    public Monthly(int y, int m, int d, String des)
    {
        // initialise instance variables
        month = m;
        day = d;
        year = y;
        description = des;
    }
}

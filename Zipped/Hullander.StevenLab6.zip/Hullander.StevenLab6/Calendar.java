import java.util.ArrayList;
/**
 * Write a description of class Calendar here.
 * 
 * @author (Chelsea Merriman) 
 * @version (2/14/2015)
 */
public class Calendar
{
    //ArrrayList of appointment objects
    private ArrayList<Appointment> appts = new ArrayList<Appointment>();

    //Constructor for objects of class Calendar
    public Calendar()
    {
        
    }
    //Method that adds an appointment to the array list
    public void add(Appointment appt)
    {
        appts.add(appt);
    }
    //Method that removes an appointment from the list if the occurs on method returns true
    public void remove(int year, int month, int day)
    {
        for(int i = 0; i < appts.size(); i++)
        {
            //calling the occursOn method for the object j to check the parameters
            if(appts.get(i).occursOn(year, month, day) == true)
            {
                appts.remove(i);
                //decrement i to prevent skipping
                i--;
            }
        }
    }
    public String toString()
    {
        //initlaizing a black string
        String retrVal = "";
        //for loop to go through the array list
        for(int i = 0; i < appts.size(); i++)
        {
            //calling the toString method of the current appt of the list
            retrVal = retrVal + appts.get(i).toString() + "\n";
        }
        return retrVal;
    }
}

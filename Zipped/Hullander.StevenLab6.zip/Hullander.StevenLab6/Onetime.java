
/**
 * Write a description of class Onetime here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Onetime extends Appointment
{
    //Constructor for objects of class Onetime
    public Onetime(int y, int m, int d, String des)
    {
        // initialise instance variables
        month = m;
        day = d;
        year = y;
        description = des;
    }
}

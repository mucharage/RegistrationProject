/**
 * Demonstration of the Calendar and Appointment classes
 */
public class AppointmentDemo {
	public static void main(String[] args) {
		Calendar calendar = new Calendar();
		//create some appointments and add them to our calendar
		//note the method calls here imply that
		//your Appointment class will need to have a 4 argument constructor
		//that accepts year, month, day, and description
		//the first call is year:2000, month: 8, day: 13
		calendar.add(new Daily(2000, 8, 13, "Brush your teeth."));
		calendar.add(new Monthly(2003, 5, 20, "Visit grandma."));
		calendar.add(new Onetime(2004, 11, 2, "Dentist appointment."));
		calendar.add(new Onetime(2004, 10, 31, "Trick or Treat."));
		calendar.add(new Monthly(2004, 11, 2, "Dentist appointment."));
		calendar.add(new Onetime(2004, 11, 2, "Dentist appointment."));

		//note here we can simply use + calendar because we have
		//implemented the toString() method
		System.out.println("Before removal of appointment " + "\n" + calendar);
		calendar.remove(2004, 11, 2);
		//note that the daily appointment is removed because it occurs on
		//11/2/2004 (as well as many other days).  
		System.out.println("After removal of 11/2/2004 " + "\n" + calendar);
		
		//creating a new calendar
		Calendar calendar2 = new Calendar();
		//adding appointments to the calendar
		calendar2.add(new Monthly(2013, 2, 5, "Check-up."));
		calendar2.add(new Daily(2012, 7, 26, "Teeth cleaning."));
		calendar2.add(new Onetime(2013, 2, 5, "Sick patient."));
		calendar2.add(new Monthly(2011, 9, 20, "Teeth cleaning."));
		calendar2.add(new Monthly(2013, 2, 5, "Check-up."));
		calendar2.add(new Onetime(2013, 6, 18, "Braces."));
		calendar2.add(new Monthly(2013, 2, 5, "Check-up."));
		calendar2.add(new Onetime(2012, 6, 26, "Sick patient."));
		System.out.println("Before removal of appointment " + "\n" + calendar2);
		//removing the appointments on day 2/5/2013
		calendar2.remove(2013, 2, 5);
		System.out.println("After removal of 2/5/2013 " + "\n" + calendar2);
		
		
		
		
		
	}
}
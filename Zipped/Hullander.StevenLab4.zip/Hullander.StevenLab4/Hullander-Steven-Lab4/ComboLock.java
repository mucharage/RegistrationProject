/**
   A class to simulate a combination lock.
*/
public class ComboLock
{
   
    //********* you will need to create appropriate instance variables here
   private int currentNumber = 0; //current value lock dial is set to
   //more variables here ....
   int[] sec = new int[3];
   int status;
   int counter;
   /**
      Initializes the combination of the lock.
      
   */
   //**** COMPLETE THIS CONSTRUCTOR - input should be 3 number combination
   //**** You may need to set other instance variables other than the 
   //**** arguments here
   //You should verify that the secret number are in the range 0-39 (inclusive)
   //if the values given are not in that range, clamp them.
   //i.e. the call new ComboLock(0, -20, 45) would create a combination of
   // 0, 0, 39  (the -20 gets clamped to 0 because it was less than 0)
   // (the 45 gets clamped to 39 because it was > 39).
   public ComboLock(int secret1, int secret2, int secret3)
   {
       //initialize instance variables
      sec[0] = secret1;
      sec[1] = secret2;
      sec[2] = secret3;
   }
   /**
      Resets the status of the lock so that it can be opened again.
   */
   //********* COMPLETE THIS METHOD
   public void reset()
   { //set currentNumber and status = 0 for re-testing
      currentNumber=0;
      status=0;
   }

   /**
      Turns lock left given number of ticks.
      @param ticks number of ticks to turn left
   */
   //*********COMPLETE THIS METHOD
   //you can assume that ticks will be a valid value between 0-40 
   //note that 40 ticks in either direction should return us back to the 
   //number we started on
   public void turnLeft(int ticks)
   {
       if(currentNumber + ticks > 39)
       {
           //consider numbers only 0-39 so if past 0, subtract 40
           currentNumber = (currentNumber + ticks) - 40;
       }
       else
       {
           //set current number to the current number plus the amount of ticks
           currentNumber = (currentNumber + ticks);
       }
       if(status == 1 && currentNumber == sec[1])
       {
           //if status is 1 and the current number equals the secret number at sec[1] increment status
           status++;
       }
       else
       {
           //set status to 0
           status=0;
       }
   }

   /**
      Turns lock right given number of ticks
      @param ticks number of ticks to turn right
   */
   //*********COMPLETE THIS METHOD
   //you can assume that ticks will be a valid value between 0-40 
   //note that 40 ticks in either direction should return us back to the 
   //number we started on
   public void turnRight(int ticks)
   {
       if(ticks > currentNumber) 
       { 
           //considers going past zero
           currentNumber = 40 - (ticks - currentNumber); 
       }
       else 
       {
           //subtract ticks from current number
           currentNumber = currentNumber - ticks;
       }
       if(status == 0 && currentNumber == sec[0])
       { 
           //if status is 0 and the current number is the same as the first secret number do status = status + 1
           status++; 
       }
       else if(status == 2 && currentNumber == sec[2])
       { 
           //if status is 2, hint: the second right rotation, and the current number is the same as the third secret number do status = status + 1
           status++; 
       }
       else 
       { 
           status = 0;
       }
    }

   /**
      Returns true if the lock can be opened now
      @return true if lock is in open status
   */
   //**** COMPLETE THIS METHOD
   public boolean open()
   {
      if(status==3)//if all secret numbers have been reached in order, the status should be 3 and the lock will open
      {
          return true;
      }
      else //if all secret numbers have not been reached in order, the status should not be 3 and the lock will not open
      {
          return false; //dummy value for now
      }
   }
   /**
   Returns current value dial is pointing at
   @return value dial is pointing at currently
    */
   public int getCurrentNumber() {
       return currentNumber;
   }
   
}
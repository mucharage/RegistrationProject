import java.util.Random;
import java.util.LinkedList;
import java.util.Iterator;
import java.util.*;
/**
 * Write a description of class Polynomial here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Polynomial
{
    //instance variables 
    LinkedList<Term> polynomial;
    /**
     * Constructor
     * 
     */
    Polynomial()
    {
        //creating a empty list
        polynomial = new LinkedList<Term>();
    }
    /**
     * 
     */
    Polynomial(Term t)
    {
        //creating a empty list
        polynomial = new LinkedList<Term>();
        //adding the terms
        polynomial.add(t);
    }    
    /**
     * An example of a method - replace this comment with your own
     * 
     * @param  y   a sample parameter for a method
     * @return     the sum of x and y 
     */
    public void add(Polynomial p)
    {
        LinkedList<Term> result = new LinkedList<Term>();
        //creating a iterator for this.polynomial
        ListIterator<Term> iteri1 = this.polynomial.listIterator();
        //creating a iterator for p.polynomial
        ListIterator<Term> iteri2 = p.polynomial.listIterator();
        //while this.poly and p.poly has more elements.. 
        while(iteri1.hasNext() && iteri2.hasNext())
        {
            Term t1 = iteri1.next();
            Term t2 = iteri2.next();
            //do this..
            //while the power of the first term in this.poly is greater than the first
            //term in p.poly, add that higher power to the result linked list
            if(t1.getPower() > t2.getPower())
            {
                //adding this term to the result list
                result.add(t1);
                //moving the iter back in p.poly
                iteri2.previous();
            }
            //if the power of the first term in this.poly is less than the first
            //term in p.poly, add the higher power to the result linked list
            else if(t1.getPower() < t2.getPower())
            {
                //adding this term to the result list
                result.add(t2);
                //moving the iter back in this.poly
                iteri1.previous();
            }
            else if (t1.getPower() == t2.getPower())//if the powers are the same....
            {
                //creating new term
                //add the coeeficients together and keep the powers
                t1.addIfSamePower(t2);
                //adding this new term to the result list
                result.add(t1);
            }
        }
        //while this.polynomial's iterator has a next value...
        while(iteri1.hasNext())
        {
             //adding the element
             
             result.add(iteri1.next());
        }
        while(iteri2.hasNext())
        {
            result.add(iteri2.next());
        }
        this.polynomial = result;
    }
    public void print()
    {
        //creating a list iterator
        ListIterator<Term> iteri3 = this.polynomial.listIterator();
        boolean term1 = true;
        //printing the polynomial
        
        while(iteri3.hasNext())
        {
            Term t = iteri3.next();
            if(term1 == true)
            {
                
                System.out.print(t.toString());
                term1 = false;
                
            }
            else if(term1 == false)
            {
                
                System.out.print(" + " + t.toString());
            }
        }
    }
    public Polynomial multiply(Polynomial p)
    {
        //creating a new polynomial 
        Polynomial retVal = new Polynomial();
        for(Term t1 : p.polynomial)
        {
            for(Term t2 : this.polynomial)
            {
                retVal.add(new Polynomial(t1.multiply(t2)));
            }
        }
        return retVal;
    }
}


/**
 * Write a description of class Term here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Term
{
    // instance variables - replace the example below with your own
    private double coefficient;
    private int power;
    
    /**
     * Constructor
     * 
     * @param  coefficient, power    
     */
    Term(double coefficient, int power)
    {
        this.coefficient = coefficient;
        this.power = power;
    }
    /**
     * A Method that retrieves the coefficient of the term
     * 
     * @return  coefficient 
     */
    public double getCoefficient()
    {
        return coefficient;
    }
    /**
     * A method that retrieves the power of the term
     * 
     * @return  power
     */
    public int getPower()
    {
        return power;
    }
    /**
     * Method that multiplies
     * 
     * @param   Term    ......
     * @return  
     */
    public Term multiply(Term t)
    {
       //multiplying coefficients
       double coeff = this.getCoefficient() * t.getCoefficient();
       //adding the powers
       int p = this.getPower() + t.getPower(); 
       
       //creating new Term
       Term retVal = new Term(coeff,p);
       //returning that value
       return retVal;
    }
    /**
     * Method that adds the terms together if the two terms have the same power
     * 
     * @param   Term    ....
     */
    public void addIfSamePower(Term t)
    {
        //if the powers are the same...
        if(this.getPower() == t.getPower())
        //then add the coefficients
        {
            coefficient = this.getCoefficient() + t.getCoefficient();
            Term retVal = new Term(coefficient,power);
        }
        Term retVal = new Term(coefficient,power);
    }
    /**
     * Method to override the toString() method
     */
    public String toString()
    {
        //make the polynomial a string
        String str;
        str = coefficient + "x^" + power + " ";
        if(power > 1)
        {
            str = coefficient + "x^" + power;
        }
        else if(power < 1)
        {
            str = coefficient + " ";
        }
        else if(power == 1)
        {
            str = coefficient + "x";
        }
        return str;
    }
}


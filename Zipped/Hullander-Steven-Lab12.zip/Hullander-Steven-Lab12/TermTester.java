
/**
 * This class tests the term class 
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class TermTester 
{
    public static void main(String[] args)
    {
        //creating 2 terms
        Term t1 = new Term(5,2);
        Term t2 = new Term(2,5);
        //testing the multiply method
        System.out.println("5.0x^2 X 2.0x^5");
        Term t3 = t1.multiply(t2);
        System.out.println("Answer: " + t3);
        System.out.println("Expected Value: 10.0x^7");
        System.out.println();
        
        //testing the add method
        Term t4 = new Term(10,2);
        Term t5 = new Term(5,2);
        System.out.println("10.0x^2 + 5.0x^2");
        //adding t4 to itself
        t4.addIfSamePower(t5);
        System.out.println("Answer: " + t4);
        System.out.println("Expected Value: 15.0x^2");
        System.out.println();
        
        //testing the getCoefficient method
        System.out.println("Getting the coefficient of 5.0x^2.");
        double co = t1.getCoefficient();
        System.out.println("Coefficient: " + co);
        System.out.println("Expected: 5.0");
        System.out.println();
        
        //testing the getPower method
        System.out.println("Getting the power of 2.0x^5.");
        int pow = t2.getPower();
        System.out.println("Power: " + pow);
        System.out.println("Expected: 5");
        System.out.println();
        
        
    
    
    

    


   }
}

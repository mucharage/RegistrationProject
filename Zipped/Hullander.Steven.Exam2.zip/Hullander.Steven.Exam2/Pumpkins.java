
/**
 * Pumpkins remaining at the end of the day.
 * 
 * @author (Steven Hullander) 
 * @version (10/13/2014)
 */
public class Pumpkins
{
    // instance variable
    private int numberOfPumpkins;
    public Pumpkins(int x)
     {
        // initialise instance variables
        numberOfPumpkins = x;
     }
    public void purchasePumpkin()
     {
        numberOfPumpkins = (numberOfPumpkins -1);
     }
    public int getPumpkinCount()
     {
        return numberOfPumpkins; 
     }    
}

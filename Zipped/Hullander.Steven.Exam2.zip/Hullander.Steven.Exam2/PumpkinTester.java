
/**
 * Pumpkin Tester Class
 * 
 * @author (Steven Hullander) 
 * @version (10/13/2014)
 */
import java.util.Scanner;
public class PumpkinTester
{
   public static void main(String[] args)
     {
         Scanner in = new Scanner(System.in);
         System.out.print("How many pumpkins are there to start the day? " );
         int initialPumpkins = in.nextInt();
         Pumpkins steven = new Pumpkins(initialPumpkins);
         steven.purchasePumpkin();
         steven.purchasePumpkin();
         steven.purchasePumpkin();
         steven.purchasePumpkin();
         steven.purchasePumpkin();
         System.out.print("It appears there are " + steven.getPumpkinCount() + " pumpkins remaining!");
     }
}

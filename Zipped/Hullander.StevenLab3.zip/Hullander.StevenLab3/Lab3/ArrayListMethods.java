import java.util.Collections; //need this one for sorting ArrayList
import java.util.Random;
import java.util.ArrayList;

public class ArrayListMethods {
    
    //ArrayList to hold values to work on for lab
    private ArrayList<Integer> listValues;

    //ArrayList constructor
    public ArrayListMethods(ArrayList<Integer> initialValues) {
        //note this shows how to make a copy of an array list
        //simply pass the old list in as an argument to 
        //the ArrayList constructor
        listValues = new ArrayList<Integer>(initialValues);
    }
    
    //set listValues to list passed as parm
    //use this method to "reset" our ArrayList data before each test
    public void setListValues(ArrayList<Integer> newValues) {
        listValues = new ArrayList<Integer>(newValues);
    }
    
    //Accessor method to get the list values
    public ArrayList<Integer> getListValues() {
        return listValues;
    }
    
    //method to print the current values in the ArrayList
    //or you can simply use println() with the array list as the
    //parameter
    public void printArrayList() {
        System.out.println(listValues);
    }
    
    //part a, done for you.
    public void swapFirstAndLast() {
        //save first element
        int temp = listValues.get(0);
        //move last element to first position (0)
        listValues.set(0,  listValues.get(listValues.size()-1));
        //put temp value into last position (size() -1)
        listValues.set(listValues.size()-1, temp);
    }
    
    
    //part b, fill in this method
    public void shiftRight() {
        //saving the array's last index value to a temporary variable
        int temp = listValues.get(listValues.size()-1);
        //assigning the new values one position to the right
        for(int i = listValues.size()-1; i > 0; i--)
        {
            listValues.set(i, listValues.get(i-1));  //set the value equal to the value of the element before it
        }
        listValues.set(0, temp);
    }
    
    
    //part c, set all even elements to 0.
    public void setEvensToZero() {
        for(int i=0; i < listValues.size(); i++)
        {
          if(listValues.get(i)%2==0) //if the element divided by 2 has a remainder of 0
          {
            listValues.set(i, 0); //set the even element value to 0
          }
        }
    }
    
    
    //part d, replace each element except the first and last by larger of two 
    //around it
    public void largerOfAdjacents() {
        ArrayList<Integer> newVals = new ArrayList<Integer>(listValues);//new array to hold
        newVals.set(0, listValues.get(0)); //set the first elements of the arrays equal
        newVals.set(newVals.size()-1, listValues.get(listValues.size()-1));
        for(int i=1; i<listValues.size()-1; i++)
        {
          if(listValues.get(i-1) > listValues.get(i+1)) //check if the value to the left is bigger than the value to the right
          {
             newVals.set(i, listValues.get(i-1)); //set the value equal to the value of the elemen  t before it
          }
          else
          {
             newVals.set(i, listValues.get(i+1)); //set the value equal to the value of the element after it
          }
        }
        System.out.println(newVals); //print new array
    }
    
    
    //part e, remove middle el if odd length, else remove middle two els.
    public void removeMiddle() {
        if(listValues.size() % 2 == 0) //check if the array length is even
        {
            int rem = (listValues.size() / 2);
            listValues.remove(rem-1);
            listValues.remove(rem-1);
        }
        else
        {
            listValues.remove(listValues.size() / 2);
        }
    }
    
    
    //part f - move all evens to front
    public void moveEvensToFront() {
        for(int i=0; i<listValues.size(); i++)
        {
            if(listValues.get(i) % 2 == 0)
            {
                int holder = listValues.get(i);
                listValues.remove(i);
                listValues.add(0,holder);
            }
        }
    }
    
    
    //part g - return second largest el in array
    public int ret2ndLargest() {
        Collections.sort(listValues);
        int secHigh = listValues.get(listValues.size()-2); //set the second largest value to secHigh
        System.out.println("The second highest values is: " + secHigh + "."); //print the second largest value
        return secHigh; //dummy value
    }
    
    
    //part H - returns true if array is sorted in increasing order 
    public boolean isSorted() {
        boolean isSorted = false; //initially assume list is not sorted
        for(int i=0; i<listValues.size()-1; i++)
        {
            if(listValues.get(i)>listValues.get(i+1))//test if the elements value is larger than the next elements value
            {
                System.out.println("The arraylist is NOT sorted!");
                return false;
            }
            else
            {
                System.out.println("The array IS sorted in numerical order!");
                return true;
            }
        }
        return isSorted; //dummy value
    }
    
    
    //PART I - return true if array contains 2 adjacent duplicate values
    public boolean hasAdjDuplicates() {
        boolean hasDup = false; //assume no duplicates, then search array
        int count=0;
        for(int i = 0; i < listValues.size()-1 && count <=0; i++)
        {
            if(listValues.get(i) == listValues.get(i+1)) //test if an elements value is equal to the next elements value
            {
                System.out.println("The first or only elements with the same value, have a value of: " + listValues.get(i) + "." );
                count++; //update count by 1
                return true;
            }
        }
        if(count <= 0)
        {
            System.out.println("The following array contains no elements with 2 exact values in the adjacent elements." );
            return false;
        }
        return hasDup;
    }
    
    
    //PART J - return true if array contains 2 duplicate values
    //duplicates need not be adjacent to return true
    public boolean hasDuplicates() {
        boolean hasDup = false; //assume no duplicates, then search array
        Collections.sort(listValues);
        int count=0; //initialize count
        for(int i = 0; i < listValues.size()-1 && count <=0 ;i++)
        {
            if(listValues.get(i) == listValues.get(i+1))
            {
                System.out.println("The first or only elements with the same value, have a value of: " + listValues.get(i) + "." );
                return true;
            }
        }
        if(count <= 0)
        {
            System.out.println("The following array contains no elements with 2 exact values." );
            return false;
        }
        return hasDup;
    }
    
    public static void main(String[] args) {
        //In your main method you should test your array methods
        //First fill an array with random values
        Random myGen = new Random();
        final int TEST_SIZE = 10;
        //our initial random test data goes into the following array list
        //don't make changes to this array, it will hold your test data
        ArrayList<Integer> listTestValues = new ArrayList<Integer>();
        //fill in test arrayList
        for (int i=0; i<TEST_SIZE; i++) {
            //fills the array List with random ints between 1 and 50 inclusive
            listTestValues.add(1+myGen.nextInt(50));
        }
        
        //Now print the array list to show initial values
        System.out.println("Initial Array List:");
        //you can use the following line to print the list
        System.out.println(listTestValues);
        System.out.println();
        
        //from here you should fill in code that tests parts a-j 
        //for problem E7.2 from the textbook
        //part a is done for you below.  You should follow this format
        //to test each of your methods.
        //create a new ArrayListMethods object.
        //note the following line will also initialize our arraylist data
        ArrayListMethods myMethods = new ArrayListMethods(listTestValues);
        
        //Test methods below this line.
        //Test of swapFirstAndLast()
        System.out.println("Before call to swapFirstAndLast():");
        System.out.println(myMethods.listValues);
        //swap first and last element
        myMethods.swapFirstAndLast();
        System.out.println("After call to swapFirstAndLast():");
        System.out.println(myMethods.listValues);
        System.out.println();
        //reset the Array List to the initial test values
        myMethods.setListValues(listTestValues);
        
        //***Begin second test below this line
        //Test of shiftRight()
        System.out.println("Before call to shiftRight():");
        System.out.println(myMethods.listValues);
        //shift elements the to the right
        myMethods.shiftRight();
        System.out.println("After call to shiftRight():");
        System.out.println(myMethods.listValues);
        System.out.println();
        //reset the Array List to the initial test values
        myMethods.setListValues(listTestValues);
        
        //Test of setEvensToZero()
        System.out.println("Before call to setEvensToZero():");
        System.out.println(myMethods.listValues);
        //set Evens To Zero
        myMethods.setEvensToZero();
        System.out.println("After call to setEvensToZero():");
        System.out.println(myMethods.listValues);
        System.out.println();
        //reset the Array List to the initial test values
        myMethods.setListValues(listTestValues);
        
        //Test of largerOfAdjacents()
        System.out.println("Before call to largerOfAdjacents():");
        System.out.println(myMethods.listValues);
        System.out.println("After call to largerOfAdjacents():");
        //set element to the larger Of it's Adjacents
        myMethods.largerOfAdjacents();
        System.out.println();
        //reset the Array List to the initial test values
        myMethods.setListValues(listTestValues);
        
        //Test of removeMiddle()
        System.out.println("Before call to removeMiddle():");
        System.out.println(myMethods.listValues);
        //removing Middle elements
        myMethods.removeMiddle();
        System.out.println("After call to removeMiddle():");
        System.out.println(myMethods.listValues);
        System.out.println();
        //reset the Array List to the initial test values
        myMethods.setListValues(listTestValues);
        
        //Test of moveEvensToFront()
        System.out.println("Before call to moveEvensToFront():");
        System.out.println(myMethods.listValues);
        //rmoving evens to the front
        myMethods.moveEvensToFront();
        System.out.println("After call to moveEvensToFront():");
        System.out.println(myMethods.listValues);
        System.out.println();
        //reset the Array List to the initial test values
        myMethods.setListValues(listTestValues);
        
        //Test of ret2ndLargest()
        System.out.println("Before call to ret2ndLargest():");
        System.out.println(myMethods.listValues);
        System.out.println("After call to ret2ndLargest():");
        //return the second largest element
        myMethods.ret2ndLargest();
        System.out.println();
        //reset the Array List to the initial test values
        myMethods.setListValues(listTestValues);
        
        //Test of isSorted()
        System.out.println("Before call to isSorted() when the list is in random order:");
        System.out.println(myMethods.listValues);
        //see if the arrayList is sorted
        myMethods.isSorted();
        System.out.println();
        //reset the Array List to the initial test values
        myMethods.setListValues(listTestValues);
        
        //Test of isSorted()
        System.out.println("Before call to isSorted() when the list is already sorted:");
        Collections.sort(myMethods.listValues);
        System.out.println(myMethods.listValues);
        //see if the arrayList is sorted
        myMethods.isSorted();
        System.out.println();
        //reset the Array List to the initial test values
        myMethods.setListValues(listTestValues);
        
        //Test of hasAdjDuplicates()
        System.out.println("Before call to hasAdjDuplicates():");
        System.out.println(myMethods.listValues);
        System.out.println("After call to hasAdjDuplicates():");
        //see if arraylist has adjacent duplicates
        myMethods.hasAdjDuplicates();
        System.out.println();
        //reset the Array List to the initial test values
        myMethods.setListValues(listTestValues);
        
        //Test of hasDuplicates()
        System.out.println("Before call to hasDuplicates():");
        System.out.println(myMethods.listValues);
        System.out.println("After call to hasDuplicates():");
        //see if arraylist has any duplicates
        myMethods.hasDuplicates();
        System.out.println();
        //reset the Array List to the initial test values
        myMethods.setListValues(listTestValues);
    }
}
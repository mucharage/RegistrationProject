
/**
 * Write a description of class Problem1 here.
 * 
 * @author (Steven Hullander) 
 * @version (11/17/2014)
 */
public class Employees
{
    // instance variable to hold array
    private String name;
    private double salary;
    public double bonus;
    //Constructor
    public Employees(String n, double s)
    {
        // initialise instance variable
        name = n;
        salary = s;
    }
    //Method to get employee name
    public String getName()
    {
        return name;
    }
    //Method to get employee salary
    public double getSalary()
    {
        return salary;
    }
    //Method to get the employees bonus
    public double getBonus()
    {
        bonus = (salary * .10);
        return bonus;
    }
}


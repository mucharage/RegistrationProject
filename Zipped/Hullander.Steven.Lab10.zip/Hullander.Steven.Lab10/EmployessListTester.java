
/**
 * Write a description of class EmployessTester here.
 * 
 * @author (steven hullander) 
 * @version (11/22/2014)
 */
import java.util.ArrayList;
import java.util.Scanner;
public class EmployessListTester
{
    public static void main(String[]args)
    {
       ArrayList<EmployeesList> arr = new ArrayList<EmployeesList>();
       for(int i=0; i<=4; i++) 
        {
            Scanner in = new Scanner(System.in);
            System.out.printf("Please enter the employee name: ");
            String n = in.nextLine();
            System.out.printf("Please enter the employee salary: ");
            double s= in.nextDouble();                  
            arr.add(new EmployeesList(n, s));
        }
       for(int i=0; i<=4; i++) 
        {
           System.out.println(arr.get(i).getName() + " has a salary of " + arr.get(i).getSalary() + " and will recieve a bonus of " + arr.get(i).getBonus());
        }
    }
}

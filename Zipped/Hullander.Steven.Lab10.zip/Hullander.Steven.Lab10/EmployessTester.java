
/**
 * Write a description of class EmployessTester here.
 * 
 * @author (steven hullander) 
 * @version (11/22/2014)
 */
import java.util.Scanner;
public class EmployessTester
{
    public static void main(String[]args)
    {
       Employees[] arr = new Employees[5];
       for(int i=0; i<=4; i++) 
        {
            Scanner in = new Scanner(System.in);
            System.out.printf("Please enter the employee name: ");
            String n = in.nextLine();
            System.out.printf("Please enter the employee salary: ");
            double s= in.nextDouble();
            arr[i] = new Employees(n,s);
        }  
       for(int i=0; i<=4; i++) 
        {
            System.out.println(arr[i].getName() + " has a salary of " + arr[i].getSalary() + " and will recieve a bonus of " + arr[i].getBonus());
        }
    }
}

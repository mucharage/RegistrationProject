
/**
 * Math Operations.
 * 
 * @author (Steven Hullander) 
 * @version (11/17/2014)
 */
import java.util.Scanner;
public class mathOpTester
{
    public static void main(String[] args)
    {
     Scanner in = new Scanner(System.in);
     double[] holdList = new double[10];
     for(int i=0; i<=9; i++)
     {
       System.out.print("Please enter a number: ");
       double inputArr = in.nextDouble();
       holdList[i] = inputArr;
     }
     System.out.print("Enter a number to find the amount of elements with values higher than your number: ");
     double inputEle = in.nextDouble();
     mathOp ray = new mathOp(holdList);
     System.out.print("The range of the array is: " + ray.getRange());
     System.out.println(" ");
     System.out.print("The sum of the values entered is: " + ray.getSum());
     System.out.println(" ");
     System.out.print("The number of elements above the single number you entered is: " + ray.getAbove(inputEle));
    }
}
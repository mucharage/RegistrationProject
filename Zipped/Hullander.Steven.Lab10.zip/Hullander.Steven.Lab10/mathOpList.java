
/**
 * mathOp but with an ArrayList.
 * 
 * @author (Steven Hullander) 
 * @version (11/17/2014)
 */
import java.lang.Double;
import java.util.ArrayList;
public class mathOpList
{
    // instance variable to hold array
    private ArrayList<Double> holdNums;
    private double above;
    public int eleAbove=0;
    public double sum=0;
    public double max =0;
    public double min =0;
    //Constructor
    public mathOpList(ArrayList<Double> a)
    {
        // initialise instance variable
        holdNums = a;
        above = 0;
    }
    //Method to find the difference between the Max and Min
    public double getRange()
    {
        for(int i=0; i<=9; i++)
        {
          if(max < holdNums.get(i))
          {
             max = holdNums.get(i);
          }
        }
        min=max;
        for(int i=9; i>=0; i--)
        {
          if(min > holdNums.get(i))
          {
             min = holdNums.get(i);
          }
        }
        return (max-min);
    }
    //Method to find the sum of all elements
    public double getSum()
    {
        for(int i=0; i<=9; i++)
        {
           sum = (sum + holdNums.get(i));
        }
        return sum;
    }
    //Method to find the number of elements above an UI number
    public double getAbove(double a)
    {
        above = a;
        for(int i=0; i<=9; i++)
        {
            if(above<holdNums.get(i))
            {
                eleAbove++;
            }
        }
        return eleAbove;
    }
}


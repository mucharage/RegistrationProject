
/**
 * Math Operations ArrayList.
 * 
 * @author (Steven Hullander) 
 * @version (11/17/2014)
 */
import java.util.ArrayList;
import java.util.Scanner;
public class mathOpListTester
{
    public static void main(String[] args)
    {
     Scanner in = new Scanner(System.in);
     ArrayList<Double> names = new ArrayList<Double>();
     for(int i=0; i<=9; i++)
     {
       System.out.print("Please enter a number: ");
       double inputArr = in.nextDouble();
       names.add(inputArr);
     }
     System.out.print("Enter a number to find the amount of elements with values higher than your number: ");
     double inputEle = in.nextDouble();
     mathOpList ray = new mathOpList(names);
     System.out.print("The range of the array is: " + ray.getRange());
     System.out.println(" ");
     System.out.print("The sum of the values entered is: " + ray.getSum());
     System.out.println(" ");
     System.out.print("The number of elements above the single number you entered is: " + ray.getAbove(inputEle));
    }
}
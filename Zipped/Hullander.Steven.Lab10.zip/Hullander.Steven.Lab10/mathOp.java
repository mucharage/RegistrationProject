
/**
 * Write a description of class Problem1 here.
 * 
 * @author (Steven Hullander) 
 * @version (11/17/2014)
 */
public class mathOp
{
    // instance variable to hold array
    private double[] holdNums;
    private double above;
    public int eleAbove=0;
    public double sum=0;
    public double max =0;
    public double min =0;
    //Constructor
    public mathOp(double[] a)
    {
        // initialise instance variable
        holdNums = a;
        above = 0;
    }
    //Method to find the difference between the Max and Min
    public double getRange()
    {
        for(int i=0; i<=9; i++)
        {
          if(max < holdNums[i])
          {
             max = holdNums[i];
          }
        }
        min=max;
        for(int i=9; i>=0; i--)
        {
          if(min > holdNums[i])
          {
             min = holdNums[i];
          }
        }
        return (max-min);
    }
    //Method to find the sum of all elements
    public double getSum()
    {
        for(int i=0; i<=9; i++)
        {
           sum = (sum + holdNums[i]);
        }
        return sum;
    }
    //Method to find the number of elements above an UI number
    public double getAbove(double a)
    {
        above = a;
        for(int i=0; i<=9; i++)
        {
            if(above<holdNums[i])
            {
                eleAbove++;
            }
        }
        return eleAbove;
    }
}


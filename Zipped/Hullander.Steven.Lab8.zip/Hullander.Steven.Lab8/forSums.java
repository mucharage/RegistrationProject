
/**
 * sum of even numbers and squares using for loops
 * 
 * @author (Steven Hullander) 
 * @version (11/3/2014)
 */
public class forSums
{
   public static void main(String[] args)
   {
       int evenSum= 0;
       for(int evenNumber = 2; evenNumber <= 100; evenNumber = (evenNumber + 2))
        {
           evenSum = (evenSum + evenNumber);
        }
       System.out.println("The sum of all even numbers from 2-200 is " + evenSum);
       int squareValue = 0;
       int squareSum = 0;
       for(int number = 1; number <=10; number++)
        {
           squareValue = (number * number);
           squareSum = (squareSum + squareValue);
        }
           System.out.println("The sum of squares between 1-100 is " + squareSum);
   }
}


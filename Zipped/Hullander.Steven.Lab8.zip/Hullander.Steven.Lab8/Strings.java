
/**
 * messing with strings
 * 
 * @author (Steven Hullander) 
 * @version (11/3/2014)
 */
import java.util.Scanner;
public class Strings
{
  public static void main(String[] args)
  {
      Scanner in = new Scanner(System.in);
      System.out.print("Please enter a string: ");
      String input = in.nextLine();
      int start = 1;
      do 
      {
        String skipOne = (input.substring(start, (start + 1)));
        System.out.print(skipOne + " ");
        start = (start + 2);
      }
      while(start < input.length());
  }
}
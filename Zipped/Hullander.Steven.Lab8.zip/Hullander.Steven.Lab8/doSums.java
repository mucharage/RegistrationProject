
/**
 * sum of even numbers and squares using do loops
 * 
 * @author (Steven Hullander) 
 * @version (11/3/2014)
 */
public class doSums
{
   public static void main(String[] args)
   {
       int evenSum = 0;
       int evenNumber = 2;
       do
       {
           evenSum = (evenSum + evenNumber);
           evenNumber = (evenNumber + 2);    
       }
       while(evenNumber <= 100);
       System.out.println("The sum of all even numbers from 2-200 is " + evenSum);
       int squareSum = 0;
       int number = 1;
       int squareValue = 0;
       do
       {
           squareValue = (number * number);
           squareSum = (squareSum + squareValue);
           number++;    
       }
       while(number <= 10);
       System.out.println("The sum of squares between 1-100 is " + squareSum);
   }
}


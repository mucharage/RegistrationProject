
/**
 * Write a description of class testing here.
 * 
 * @author (Steven Hullander) 
 * @version (11/10/2014)
 */
public class Numbers
{
   public static void main(String[] args)
   {
      for(int row = 1; row < 10; row++)
          { 
            for(int columns = 1; columns <= row; columns++)
                {
                    System.out.print(columns + " ");
                }
            System.out.println();
          }
   }
}
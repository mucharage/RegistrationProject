import java.util.Arrays;
import java.util.Random;


public class ArrayMethods {
    // you will put numerical elements into the "values" array before
    // each test of your methods.  Your methods should operate on this array.
    // For each test you run, you should first print the values[] array before
    // the method call, and then after the method call.  (See sample output file).
    private int[] values;

    //constructor - give it an array of initial values and they will
    // be copied into the values instance variable
    public ArrayMethods(int[] initialValues) 
    {
        values = Arrays.copyOf(initialValues, initialValues.length);
    }
    
    //a function to reset the array to the values passed in as a parameter
    //you will want to use this method after each test you do in the main
    //method
    public void setValues(int[] newValues) 
    {
        values = Arrays.copyOf(newValues, newValues.length);
    }
    
    //helper method to print the values array
    public void printArray() 
    {
        System.out.println(Arrays.toString(values));
    }
    
    //accessor to get a reference to the values array
    public int[] getValues() 
    {
        return values;
    }
    
    //part a, fill in this method
    public void swapFirstAndLast() 
    {
        // save the first element to a temp var
        int temp = values[0];
        //move the last element to the first position
        values[0] = values[values.length-1];
        // now put the saved first element into the last position
        values[values.length-1] = temp;
    }
    
    //part b, fill in this method
    public void shiftRight() 
    {
        //saving the array's index values to temporary variables
        int  temp = values[values.length-1];
        //assigning the new values one position to the right
        for(int i = values.length-1; i > 0; i--)
        {
          values[i]= values[i-1]; //set the value equal to the value of the element before it
        }
        values[0]=temp;
    }
    
    //part c, set all even elements to 0.
    public void setEvensToZero()
    {
        for(int i=0; i<values.length; i++)
        {
          if(values[i]%2==0) //if the element divided by 2 has a remainder of 0
          {
             values[i]=0; //set the even element value to 0
          }
        }
    }
    
    //part d, replace each element except the first and last by larger of two 
    //around it
    public void largerOfAdjacents() 
    {
        int[] newVals = new int[values.length]; //new array to hold
        newVals[0] = values[0]; //set the first elements of the arrays equal
        newVals[values.length-1] = values[values.length-1];
        for(int i=1; i<values.length-1; i++)
        {
          if(values[i-1] > values[i+1]) //check if the value to the left is bigger than the value to the right
          {
             newVals[i] = values[i-1]; //set the value equal to the value of the element before it
          }
          else
          {
             newVals[i] = values[i+1]; //set the value equal to the value of the element after it
          }
        }
        System.out.println(Arrays.toString(newVals)); //print new array
    }
    
    //part e, remove middle el if odd length, else remove middle two els.
    public void removeMiddle() 
    {
        if(values.length % 2 == 0) //check if the array length is even
        {
            for(int i=(values.length / 2); i<values.length-1; i++)
            {
               values[i-1] = values[i+1]; //set the value to the left equal to the value of the element to the right of it
            }
            int[] removArr = Arrays.copyOf(values,values.length-2); //create a new array with the same values as the "values" array with a length 2 smaller
            System.out.println(Arrays.toString(removArr)); //print the array
        }
        else
        {
            for(int i=(values.length / 2); i<values.length-1; i++)
            {
               values[i] = values[i+1]; //set the value to the left equal to the value of the element to the right of it
            }
            int[] removArr = Arrays.copyOf(values,values.length-1); //create a new array with the same values as the "values" array with a length 1 smaller
            System.out.println(Arrays.toString(removArr));//print the array
        }
    }
    
    //part f - move all evens to front
    public void moveEvensToFront() 
    {
        int pos = 0;
        for(int i = 0; i < values.length; i++)
        {
            if(values[i] % 2 == 0)
            {
                int holder = values[pos];
                values[pos] = values[i];
                values[i] = holder;
                pos++;
            }
        }
    }
    
    //part g - return second largest el in array
    public int ret2ndLargest() 
    {
        int secLargest = values[values.length-2]; //set the second to last value to a variable since they were put in order in the tester
        System.out.println("The second largest value is: " + secLargest + "."); //print the 2nd largest value
        return secLargest;
    }
    
    //part H - returns true if array is sorted in increasing order 
    public boolean isSorted() 
    {
        for(int i=0; i < values.length-1; i++)
        if(values[i] > values[i+1]) //test if the elements value is larger than the next elements value
        {
            System.out.println("The array is NOT sorted in numerical order!");
            return false;
        }
        System.out.println("The array IS sorted in numerical order!");
        return true;
    }
    
    //PART I - return true if array contains 2 adjacent duplicate values
    public boolean hasAdjDuplicates() 
    {
        int count=0;
        for(int i = 0; i < values.length-1 && count <=0 ;i++)
        {
            if(values[i] == values[i+1]) //test if an elements value is equal to the next elements value
            {
                System.out.println("The first or only elements with the same value, have a value of: " + values[i] + "." );
                count++; //update count by 1
            }
        }
        if(count <= 0)
        {
            System.out.println("The following array contains no elements with 2 exact values in the adjacent elements." );    
        }
        return true;
    }
    
    //PART J - return true if array contains 2 duplicate values
    //duplicates need not be adjacent to return true
    public boolean hasDuplicates() 
    {
        int count=0; //inistialize count
        for(int i = 0; i < values.length-1 && count <=0 ;i++)
        {
            if(values[i] == values[i+1]) //test if an elements value is equal to the next elements value
            {
                System.out.println("The first or only elements with the same value, have a value of: " + values[i] + "." );
                count++; //update count by 1
            }
        }
        if(count <= 0)
        {
            System.out.println("The following array contains no elements with 2 exact values." );    
        }
        return true;
    }
    
    //Start of the tester
    public static void main(String[] args) {
        //In your main method you should test your array methods
        //First fill an array with random values
        Random myGen = new Random();
        final int TEST_SIZE = 10;
        //our initial random test data goes into the following array
        int[] testValues = new int[TEST_SIZE];
        for (int i=0; i<testValues.length; i++) {
            //fills the array with random ints between 1 and 50 inclusive
            testValues[i] = 1+myGen.nextInt(50);
        }
        //Now print the array to show initial values
        System.out.println("Initial Array:");
        //note the usage of the "toString()" method here to print the array
        System.out.println(Arrays.toString(testValues));
        //blank line
        System.out.println();
        
        //from here you should fill in code that tests parts a-j 
        //for problem E7.2 from the textbook
        //part a is done for you below.  You should follow this format
        //to test each of your methods.
        //create a new ArrayMethods object.
        ArrayMethods myMethods = new ArrayMethods(testValues);
        
        //Test methods below this line.
        //Test of swapFirstAndLast()
        System.out.println("Before call to swapFirstAndLast()");
        myMethods.printArray();
        //swap first and last element
        myMethods.swapFirstAndLast();
        System.out.println("After call to swapFirstAndLast()");
        myMethods.printArray();
        System.out.println();
        //reset the Array to the initial test values
        myMethods.setValues(testValues);
        
        //Test of shiftRight()
        System.out.println("Before call to shiftRight()");
        myMethods.printArray();
        //Shift elements to the right
        myMethods.shiftRight();
        System.out.println("After call to shiftRight()");
        myMethods.printArray();
        System.out.println();
        //reset the Array to the initial test values
        myMethods.setValues(testValues);
        
        //Test of setEvensToZero()
        System.out.println("Before call to setEvensToZero()");
        myMethods.printArray();
        //Sets the evens to 0
        myMethods.setEvensToZero();
        System.out.println("After call to setEvensToZero()");
        myMethods.printArray();
        System.out.println();
        //reset the Array to the initial test values
        myMethods.setValues(testValues);
        
        //Test of largerOfAdjacents()
        System.out.println("Before call to largerOfAdjacents()");
        myMethods.printArray();
        //Takes the largest of the number's two adjacents
        myMethods.largerOfAdjacents();
        System.out.println("After call to largerOfAdjacents()");
        System.out.println();
        //reset the Array to the initial test values
        myMethods.setValues(testValues);
        
        //Test of removeMiddle()
        System.out.println("Before call to removeMiddle()");
        myMethods.printArray();
        System.out.println("After call to removeMiddle()");
        //remove the middle element
        myMethods.removeMiddle();
        System.out.println();
        //reset the Array to the initial test values
        myMethods.setValues(testValues);
        
        //Test of moveEvensToFront()
        System.out.println("Before call to moveEvensToFront()");
        myMethods.printArray();
        System.out.println("After call to moveEvensToFront()");
        //move evens to front
        myMethods.moveEvensToFront();
        myMethods.printArray();
        System.out.println();
        //reset the Array to the initial test values
        myMethods.setValues(testValues);
        
        //Test of ret2ndLargest()
        System.out.println("Test of ret2ndLargest()");
        myMethods.printArray();
        //sort the array in ascending order
        Arrays.sort(myMethods.values);
        //return the 2nd largest value
        myMethods.ret2ndLargest();
        System.out.println();
        //reset the Array to the initial test values
        myMethods.setValues(testValues);
        
        //Test of isSorted()
        System.out.println("Test of isSorted() when the array is in random order.");
        myMethods.printArray();
        //the array is not sorted
        myMethods.isSorted();
        System.out.println();
        
        //Test of isSorted()
        System.out.println("Test of isSorted() when the array is already in order.");
        //sort the array in ascending order
        Arrays.sort(myMethods.values);
        myMethods.printArray();
        //the array is sorted
        myMethods.isSorted();
        System.out.println();
        //reset the Array to the initial test values
        myMethods.setValues(testValues);
        
        //Test of hasAdjDuplicates() 
        System.out.println("Test of hasAdjDuplicates()");
        myMethods.printArray();
        //call the method
        myMethods.hasAdjDuplicates();
        System.out.println();
        //reset the Array to the initial test values
        myMethods.setValues(testValues);
        
        //Test of hasDuplicates() 
        System.out.println("Test of hasDuplicates()");
        myMethods.printArray();
        Arrays.sort(myMethods.values);
        //call the method
        myMethods.hasDuplicates();
        System.out.println();
        //reset the Array to the initial test values
        myMethods.setValues(testValues);
    }
}
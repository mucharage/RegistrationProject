public class SequenceDemo
{
   public static void main(String[] args)
   {
      System.out.println("Last Digit Distribution for the first 1000 square numbers: ");
      LastDigitDistribution dist1 = new LastDigitDistribution();
      dist1.process(new SquareSequence(), 1000);
      dist1.display();
      System.out.println();
      
      System.out.println("Last Digit Distribution for 1000 random numbers: ");
      LastDigitDistribution dist2 = new LastDigitDistribution();
      dist2.process(new RandomSequence(), 1000);
      dist2.display();
      System.out.println();
      
      System.out.println("Last Digit Distribution for the first 1000 prime numbers: ");
      LastDigitDistribution dist3 = new LastDigitDistribution();
      dist3.process(new PrimeSequence(), 1000);
      dist3.display();
      System.out.println();
   }
}

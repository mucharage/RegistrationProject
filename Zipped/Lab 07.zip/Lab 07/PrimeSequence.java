public class PrimeSequence implements Sequence
{
    
    int lastPrime = 2; 
    int placeholder; 
    boolean primeFound = false; 
    int counter = 0;
    
    public int next() 
    {
        //if counter is 0, then increment counter and allow 2 to be returned as is
        if (counter == 0)
        {
            counter++;
        }
        //if counter is 1, then increment lastPrime to 3, increment counter, and allow 3 to be returned
        else if (counter == 1)
        {
            lastPrime++;
            counter++;
        }
        //if counter is greater than 1, normal generation of primes after 3 can begin
        else if (counter > 1)
        {
            //sets placeholder equal to lastPrime
            placeholder = lastPrime;
            //while a prime has not been found
            while (primeFound == false) 
            {
                //increment placeholder
                placeholder++;
                //loop to test the divisibility of placeholder by every integer between 2 and placeholder minus 1
                //if placeholder is found to be divisible by any number, then primeFound is set to false and a break statement is used to end the for loop (which causes a restart of the while loop due to primeFound being false)
                //if placeholder is not found to be divisible by a number, then primeFound is set to true
                //if the end of the for loop is reached without the loop being broken out of, then primeFound must be true and therefore the outer while loop will end
                for (int i = 2; i < (placeholder - 1); i++) 
                {
                    if (placeholder % i == 0) 
                    {
                        primeFound = false;
                        break;
                    }
                    else 
                    { 
                        primeFound = true; 
                     }
                }
            }
            //sets lastPrime equal to the placeholder
            lastPrime = placeholder;
            //sets primeFound back to false so that the while loop will function next time next() is called
            primeFound = false;
        }
            //remove the comment slashes of the below print statement to test if the 1000th prime number is correct - 7919 will be shown
            //System.out.println(lastPrime);
        //returns the prime number found
        return lastPrime;
    }
}



/**
 * Write a description of class ThanksgivingDinner here.
 * 
 * @author (steven hullander) 
 * @version (11/24/2014)
 */
public class ThanksgivingDinnerItems
{
    private int calories;
    private String name;
    public ThanksgivingDinnerItems(int c, String n)
    {
        // initialise instance variables
        calories = c;
        name = n;
    }
    public int getCalories()
    {
        return calories;
    }
    public String getName()
    {
        return name;
    }
}

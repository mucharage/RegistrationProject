
/**
 * Write a description of class GivingThanks here.
 * 
 * @author (steven hullander) 
 * @version (11/24/2014)
 */
import java.util.Scanner;
public class GivingThanks
{
     public static void main(String[] args)
    {
      String[] dinner = new String[10];
      Scanner in = new Scanner(System.in);
      for(int i=0; i<=9; i++)
      {
          System.out.print("What am I thankful for?: ");
          String n = in.nextLine();
          dinner[i]= n;
      }
      System.out.print("I am thankful for: ");
      for(int i=0; i<=9;i++)
      {
          System.out.print(dinner[i] + " ");
      }
    }
}

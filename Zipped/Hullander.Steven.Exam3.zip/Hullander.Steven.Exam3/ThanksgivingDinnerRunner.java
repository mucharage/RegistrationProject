
/**
 * Write a description of class ThanksgivingDinner here.
 * 
 * @author (steven hullander) 
 * @version (11/24/2014)
 */
import java.util.Scanner;
public class ThanksgivingDinnerRunner
{
    public static void main(String[] args)
    {
      ThanksgivingDinnerItems[] dinner = new ThanksgivingDinnerItems[10];
      for(int i=0; i<=9; i++) 
        {
            Scanner in = new Scanner(System.in);
            System.out.print("Please enter the item name: ");
            String n = in.nextLine();
            System.out.print("Please enter the number of calories for this item: ");
            int c= in.nextInt();
            dinner[i] = new ThanksgivingDinnerItems(c,n);
        }  
      System.out.print("The items for the dinner are: ");
      for(int i=0; i<=9; i++) 
        {
            System.out.print(dinner[i].getName() + " ");
        }
      System.out.println("");
      double totalCalories=0;
      for(int i=0; i<=9; i++)
        {
            totalCalories = (totalCalories + dinner[i].getCalories());
        }
      System.out.print("The total amount of calories is " + totalCalories);
    }
}

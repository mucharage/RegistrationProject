
/**
 * A class to test the method of the BankAccountInterest class.
 * 
 * @author (Steven Hullander) 
 * @version (9/29/2014)
 */
public class BankAccountInterestTester
{
    public static void main(String[] args)
    {
       BankAccountInterest harrysChecking = new BankAccountInterest (10);
       harrysChecking.addInterest(.10);
       System.out.println("The initial balance is $10.00");
       System.out.println(harrysChecking.getBalance());
       System.out.println("Expected is $11.00");
       
       BankAccountInterest johnsChecking = new BankAccountInterest (20);
       johnsChecking.addInterest(.10);
       System.out.println("The initial balance is $20.00");
       System.out.println(johnsChecking.getBalance());
       System.out.println("Expected is $22.00");
       
       BankAccountInterest stevensChecking = new BankAccountInterest (30);
       stevensChecking.addInterest(.10);
       System.out.println("The initial balance is $10.00");
       System.out.println(stevensChecking.getBalance());
       System.out.println("Expected is $33.00");
    }
}

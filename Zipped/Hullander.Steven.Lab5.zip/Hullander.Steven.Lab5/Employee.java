
/**
 * Employee class.
 * 
 * @author (Steven Hullander) 
 * @version (9/29/2014)
 */
public class Employee
{
    // instance variables
    private String name;
    private double salary;

    /**
     * Constructors for objects of class Employee
     */
    public Employee(String employeeName, double currentSalary)
    {
        name = employeeName;
        salary = currentSalary;
    }
    public String getName()
    {
        return name;
    }
    public double getSalary()
    {
        return salary;
    }
    public void raiseSalary(double byPercent)
    {
       salary = (salary +(salary * byPercent));
    }
}


/**
 * Gives details for 2 user inputted integers.
 * 
 * @author (Steven Hulander) 
 * @version (9/29/2014)
 */
import java.util.Scanner;
public class CompareInts
{
    public static void main (String[] args)
    {
        Scanner in = new Scanner(System.in);
        System.out.println("Please enter the first integer: ");
        int numberA = in.nextInt();
        System.out.println("Please enter the second integer: ");
        int numberB = in.nextInt();
        
        System.out.println("The sum is: ");
        System.out.println(numberA + numberB);
        System.out.println(" ");
        
        System.out.println("The difference is: ");
        System.out.println(numberA - numberB);
        System.out.println(" ");
        
        System.out.println("The product is: ");
        System.out.println(numberA * numberB);
        System.out.println(" ");
        
        System.out.println("The average is: ");
        System.out.println((numberA + numberB) / 2);
        System.out.println(" ");
        
        System.out.println("The absolute value of the difference is: ");
        System.out.println(Math.abs(numberA - numberB));
        System.out.println(" ");
        
        System.out.println("The maximum is: ");
        System.out.println(Math.max(numberA,numberB));
        System.out.println(" ");
        
        System.out.println("The minimum is: ");
        System.out.println(Math.min(numberA,numberB));
    }
}

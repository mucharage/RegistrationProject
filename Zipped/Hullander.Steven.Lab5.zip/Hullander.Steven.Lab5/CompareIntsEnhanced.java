
/**
 * Gives details for 2 user inputted integers in enhanced form.
 * 
 * @author (Steven Hulander) 
 * @version (9/29/2014)
 */
import java.util.Scanner;
public class CompareIntsEnhanced
{
    public static void main (String[] args)
    {
        Scanner in = new Scanner(System.in);
        System.out.println("Please enter the first integer: ");
        double numberA = in.nextInt();
        System.out.println("Please enter the second integer: ");
        double numberB = in.nextInt();
        
        System.out.println("The sum is: ");
        System.out.printf("%.2f", (numberA + numberB));
        System.out.println(" ");
        
        System.out.println("The difference is: ");
        System.out.printf("%2.2f", (numberA - numberB));
        System.out.println(" ");
        
        System.out.println("The product is: ");
        System.out.printf("%2.2f", (numberA * numberB));
        System.out.println(" ");
        
        System.out.println("The average is: ");
        System.out.printf("%2.2f", (numberA + numberB) / 2);
        System.out.println(" ");
        
        System.out.println("The absolute value of the difference is: ");
        System.out.printf("%2.2f", (Math.abs(numberA - numberB)));
        System.out.println(" ");
        
        System.out.println("The maximum is: ");
        System.out.printf("%2.2f", (Math.max(numberA,numberB)));
        System.out.println(" ");
        
        System.out.println("The minimum is: ");
        System.out.printf("%2.2f", (Math.min(numberA,numberB)));
    }
}

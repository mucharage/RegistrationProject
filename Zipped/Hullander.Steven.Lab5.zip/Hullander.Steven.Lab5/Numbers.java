
/**
 * Class for numbers raised to the 2nd,3rd, and 4th powers.
 * 
 * @author (Steven Hullander) 
 * @version (9/29/2014)
 */
import java.util.Scanner;
public class Numbers
{
    public static void main(String[] args)
    {
        Scanner in = new Scanner (System.in);
        System.out.println("Please enter an integer: ");
        int number = in.nextInt();
        
        System.out.println(number + " squared is: ");
        System.out.println(Math.pow(number,2));
        System.out.println("The expected value was: " + (number * number));
        System.out.println(" ");
        System.out.println(number + " cubed is: ");
        System.out.println(Math.pow(number,3));
        System.out.println("The expected value was: " + (number * number * number));
        System.out.println(" ");
        System.out.println(number + " to the 4th power is: ");
        System.out.println(Math.pow(number,4));
        System.out.println("The expected value was: " + (number * number * number * number));
        System.out.println(" ");
        System.out.println(" ");
        
        
        System.out.println("Please enter a double: ");
        double number2 = in.nextDouble();
        
        System.out.println(number2 + " squared is: ");
        System.out.println(Math.pow(number2,2));
        System.out.println("The expected value was: " + (number2 * number2));
        System.out.println(" ");
        System.out.println(number2 + " cubed is: ");
        System.out.println(Math.pow(number2,3));
        System.out.println("The expected value was: " + (number2 * number2 * number2));
        System.out.println(" ");
        System.out.println(number2 + " to the 4th power is: ");
        System.out.println(Math.pow(number2,4));
        System.out.println("The expected value was: " + (number2 * number2 * number2 * number2));
    }
}

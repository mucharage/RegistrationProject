
/**
 * tester for the Employee class.
 * 
 * @author (Steven Hullander) 
 * @version (9/29/2014)
 */
public class EmployeeTester
{
   public static void main(String[] arg)
   {
       Employee emp = new Employee ("Hullander",1000);
       System.out.println("Employee name: " + emp.getName());
       System.out.println("Employee salary is: " + emp.getSalary());
       emp.raiseSalary(.10);
       System.out.println("Employee new salary: " + emp.getSalary());
       System.out.println("New salary expected is 1100");
    }
}
